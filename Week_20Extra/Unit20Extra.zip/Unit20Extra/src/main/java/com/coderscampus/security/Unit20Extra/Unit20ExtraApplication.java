package com.coderscampus.security.Unit20Extra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Unit20ExtraApplication {

	public static void main(String[] args) {
		SpringApplication.run(Unit20ExtraApplication.class, args);
	}

}
