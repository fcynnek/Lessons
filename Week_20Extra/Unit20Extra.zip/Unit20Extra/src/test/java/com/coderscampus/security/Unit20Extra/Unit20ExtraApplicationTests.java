package com.coderscampus.security.Unit20Extra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Unit20ExtraApplicationTests {

	@Test
	void contextLoads() {
	}

}
