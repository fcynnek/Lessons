package com.coderscampus.Unit15;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Unit15ApplicationTests {

	@Test
	void contextLoads() {
	}

}
