package com.coderscampus.Unit18;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Unit18Application {

	public static void main(String[] args) {
		SpringApplication.run(Unit18Application.class, args);
	}

}
