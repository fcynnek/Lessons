package com.coderscampus.Unit13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Unit13Application {

	public static void main(String[] args) {
		SpringApplication.run(Unit13Application.class, args);
	}

}
