package com.coderscampus.Unit21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Unit21Application {

	public static void main(String[] args) {
		SpringApplication.run(Unit21Application.class, args);
	}

}
