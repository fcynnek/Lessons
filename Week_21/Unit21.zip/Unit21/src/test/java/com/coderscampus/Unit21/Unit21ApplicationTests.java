package com.coderscampus.Unit21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Unit21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
