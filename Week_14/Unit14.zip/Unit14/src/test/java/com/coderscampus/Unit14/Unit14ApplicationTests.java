package com.coderscampus.Unit14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Unit14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
