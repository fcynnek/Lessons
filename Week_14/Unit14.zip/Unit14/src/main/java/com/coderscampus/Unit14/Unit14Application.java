package com.coderscampus.Unit14;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Unit14Application {

	public static void main(String[] args) {
		SpringApplication.run(Unit14Application.class, args);
	}

}
